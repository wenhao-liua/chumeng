#!/system/bin/sh
# 不要假设您的模块将位于何处。
# 如果您需要知道此脚本和模块的放置位置，请使用$MODDIR
# 这将确保您的模块仍能正常工作
# 即使Magisk将来更改其挂载点
MODDIR=${0%/*}

# 此脚本将在late_start service 模式执行
# 等待开机30秒后开始执行
sleep 30

#设置小核最大频率
chmod 644 /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
echo 2035200 > /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
chmod 644 /sys/devices/system/cpu/cpu1/cpufreq/scaling_max_freq
echo 2035200 > /sys/devices/system/cpu/cpu1/cpufreq/scaling_max_freq

#设置大核最大频率
chmod 644 /sys/devices/system/cpu/cpu2/cpufreq/scaling_max_freq
echo 2630400 > /sys/devices/system/cpu/cpu2/cpufreq/scaling_max_freq
chmod 644 /sys/devices/system/cpu/cpu3/cpufreq/scaling_max_freq
echo 2630400 > /sys/devices/system/cpu/cpu3/cpufreq/scaling_max_freq
chmod 644 /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq
echo 2630400 > /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq
chmod 644 /sys/devices/system/cpu/cpu5/cpufreq/scaling_max_freq
echo 2630400 > /sys/devices/system/cpu/cpu5/cpufreq/scaling_max_freq
chmod 644 /sys/devices/system/cpu/cpu6/cpufreq/scaling_max_freq
echo 2630400 > /sys/devices/system/cpu/cpu6/cpufreq/scaling_max_freq

#设置超大核最大频率
chmod 644 /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq
echo 2803200 > /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq

#设置调速器
chmod 644 /sys/class/kgsl/kgsl-3d0/max_pwrlevel
echo 0 > /sys/class/kgsl/kgsl-3d0/max_pwrlevel

# 结束
exit 0
